package com.example.gili;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import static com.example.gili.R.layout.activity_map;

public class MapActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(activity_map);
    }
}
